<?php

namespace App\Http\Resources;

class PendingDepositCollection extends ApiCollection
{
}
