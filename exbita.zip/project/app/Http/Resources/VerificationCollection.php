<?php

namespace App\Http\Resources;

class VerificationCollection extends ApiCollection
{
}
