<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CoinpaymentsCoin extends Model
{
    protected $table = 'coinpayments_coins';


}
