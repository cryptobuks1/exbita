<?php

namespace App\Http\Resources;

class MarketCollection extends ApiCollection
{
}
