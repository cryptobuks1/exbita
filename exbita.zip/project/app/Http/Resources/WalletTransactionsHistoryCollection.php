<?php

namespace App\Http\Resources;

class WalletTransactionsHistoryCollection extends ApiCollection
{
}
